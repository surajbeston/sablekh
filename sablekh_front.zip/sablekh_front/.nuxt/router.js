import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _86ffa16c = () => interopDefault(import('../pages/forgot-password.vue' /* webpackChunkName: "pages/forgot-password" */))
const _8ebe4afa = () => interopDefault(import('../pages/library/index.vue' /* webpackChunkName: "pages/library/index" */))
const _1698beee = () => interopDefault(import('../pages/login.vue' /* webpackChunkName: "pages/login" */))
const _307bf93c = () => interopDefault(import('../pages/privacy-policy.vue' /* webpackChunkName: "pages/privacy-policy" */))
const _5783cb2e = () => interopDefault(import('../pages/register.vue' /* webpackChunkName: "pages/register" */))
const _0a81e8ff = () => interopDefault(import('../pages/terms-and-conditions.vue' /* webpackChunkName: "pages/terms-and-conditions" */))
const _4899a1ab = () => interopDefault(import('../pages/library/_id.vue' /* webpackChunkName: "pages/library/_id" */))
const _043ab44f = () => interopDefault(import('../pages/reset-password/_id.vue' /* webpackChunkName: "pages/reset-password/_id" */))
const _2a5653f7 = () => interopDefault(import('../pages/upload/_id.vue' /* webpackChunkName: "pages/upload/_id" */))
const _4cf11bd7 = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/forgot-password",
    component: _86ffa16c,
    name: "forgot-password"
  }, {
    path: "/library",
    component: _8ebe4afa,
    name: "library"
  }, {
    path: "/login",
    component: _1698beee,
    name: "login"
  }, {
    path: "/privacy-policy",
    component: _307bf93c,
    name: "privacy-policy"
  }, {
    path: "/register",
    component: _5783cb2e,
    name: "register"
  }, {
    path: "/terms-and-conditions",
    component: _0a81e8ff,
    name: "terms-and-conditions"
  }, {
    path: "/library/:id",
    component: _4899a1ab,
    name: "library-id"
  }, {
    path: "/reset-password/:id?",
    component: _043ab44f,
    name: "reset-password-id"
  }, {
    path: "/upload/:id?",
    component: _2a5653f7,
    name: "upload-id"
  }, {
    path: "/",
    component: _4cf11bd7,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
