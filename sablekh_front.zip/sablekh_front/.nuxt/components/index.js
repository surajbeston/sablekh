export { default as Footer } from '../../components/Footer.vue'
export { default as ForgotPassword } from '../../components/ForgotPassword.vue'
export { default as Library } from '../../components/Library.vue'
export { default as Login } from '../../components/Login.vue'
export { default as MyLibrary } from '../../components/MyLibrary.vue'
export { default as PasswordReset } from '../../components/PasswordReset.vue'
export { default as Privacy } from '../../components/Privacy.vue'
export { default as Register } from '../../components/Register.vue'
export { default as Search } from '../../components/Search.vue'
export { default as Terms } from '../../components/Terms.vue'
export { default as Upload } from '../../components/Upload.vue'

export const LazyFooter = import('../../components/Footer.vue' /* webpackChunkName: "components/Footer'}" */).then(c => c.default || c)
export const LazyForgotPassword = import('../../components/ForgotPassword.vue' /* webpackChunkName: "components/ForgotPassword'}" */).then(c => c.default || c)
export const LazyLibrary = import('../../components/Library.vue' /* webpackChunkName: "components/Library'}" */).then(c => c.default || c)
export const LazyLogin = import('../../components/Login.vue' /* webpackChunkName: "components/Login'}" */).then(c => c.default || c)
export const LazyMyLibrary = import('../../components/MyLibrary.vue' /* webpackChunkName: "components/MyLibrary'}" */).then(c => c.default || c)
export const LazyPasswordReset = import('../../components/PasswordReset.vue' /* webpackChunkName: "components/PasswordReset'}" */).then(c => c.default || c)
export const LazyPrivacy = import('../../components/Privacy.vue' /* webpackChunkName: "components/Privacy'}" */).then(c => c.default || c)
export const LazyRegister = import('../../components/Register.vue' /* webpackChunkName: "components/Register'}" */).then(c => c.default || c)
export const LazySearch = import('../../components/Search.vue' /* webpackChunkName: "components/Search'}" */).then(c => c.default || c)
export const LazyTerms = import('../../components/Terms.vue' /* webpackChunkName: "components/Terms'}" */).then(c => c.default || c)
export const LazyUpload = import('../../components/Upload.vue' /* webpackChunkName: "components/Upload'}" */).then(c => c.default || c)
