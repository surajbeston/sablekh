<template>
    <div class="profile">
        <div class="profile-wrapper1 mxw-100-mnh-100">
            <div class="profile11">
                <Sidebar />
            </div>
            <div class="profile12">
                <h1>asdfjasdfjaklsdf</h1>
            </div>
        </div>
        <Footer />
    </div>
</template>

<style scoped>

    .profile-wrapper1 {
        display: flex;
    }
    .profile11 {
        width: 20vw;
    }
    .profile12 {
        width: 80vw;
        min-height: 100vh;
    }
</style>