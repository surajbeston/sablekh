<template>
    <div class="search">
        <Search />
        <Footer />
    </div>
</template>

<style scoped>

</style>