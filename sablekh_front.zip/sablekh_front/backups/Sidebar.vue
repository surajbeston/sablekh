<template>
    <div class="sidebar">
        <div class="sidebar-wrapper1">
            <img class="sidebar11" src="@/assets/logo1.png" alt="loading image">
            <div class="sidebar12">
                <h1>ajsdhkjad</h1>
            </div>
            <div class="sidebar13"></div>
        </div>
    </div>
</template>

<style scoped>
    .sidebar {
        max-width: 20vw; 
        min-height: 90vh;
        box-shadow: 0 0 10px rgb(192, 192, 192);
    }
    .sidebar-wrapper1 {
        height: 90vh;
        display: flex;
        flex-direction: column;
        align-items: center;
        position: relative;
    }
    .sidebar11 {
        width: 170px;
        margin-top: 2vh;
    }
    .sidebar12 {
        margin-top: 15vh;
    }
</style>