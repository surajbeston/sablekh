<template>
    <div class="my-library">
        <MyLibrary />
        <Footer />
    </div>
</template>

<style scoped>

</style>