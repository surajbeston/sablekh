// export const state = () => ({
//     hid: ""
//   })

// export const getters = () => {  // shit getters is not avilable in nuxt's store
//     get_hid: state => {
//         return state.hid
//     }
// }
  
// export const mutations = {
//     set_hid(id) {
//         state.hid = id
//     }
//   }