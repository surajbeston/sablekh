<template>
<div class="login">
    <Terms />
    <Footer />
</div>
</template>

<style>
    
</style>