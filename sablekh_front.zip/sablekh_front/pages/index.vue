<template>
  <div class="index">
    <Search />
    <Footer />
  </div>
</template>

<script>

</script>

<style>

</style>