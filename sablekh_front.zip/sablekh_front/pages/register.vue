<template>
<div class="register">
    <Register />
    <Footer />
</div>
</template>

<style>

</style>