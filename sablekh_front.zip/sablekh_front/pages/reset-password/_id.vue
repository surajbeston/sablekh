<template>
    <div class="reset-password">
        <PasswordReset />
        <Footer />
    </div>
</template>

<style scoped>

</style>