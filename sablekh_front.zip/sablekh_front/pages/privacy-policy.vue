<template>
<div class="login">
    <Privacy />
    <Footer />
</div>
</template>

<style>
    
</style>