<template>
    <div class="upload">
        <Upload v-bind:lib_str="$route.params.id"/>
        <Footer />
    </div>
</template>

<style scoped>

</style>