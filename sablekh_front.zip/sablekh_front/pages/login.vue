<template>
<div class="login">
    <Login />
    <Footer />
</div>
</template>

<style>
    
</style>