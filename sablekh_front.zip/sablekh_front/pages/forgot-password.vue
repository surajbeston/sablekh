<template>
    <div class="forgot-password">
        <ForgotPassword />
        <Footer />
    </div>
</template>